# Doom Enemies
Adds a bunch of enemies from DOOM 2 to RoR2!

Currently adds:
- Cyberdemon (tele boss)
- Spider Mastermind (tele boss)
- Archvile (tele boss)
- Chaingunner (fodder)
- Imp (fodder)
- Cacodemon (miniboss)
- Baron of Hell (miniboss)
- Revenant (miniboss)


# Changelog
## 1.0.0
- exists
